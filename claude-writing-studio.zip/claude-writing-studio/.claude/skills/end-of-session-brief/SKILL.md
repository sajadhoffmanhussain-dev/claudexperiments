---
name: end-of-session-brief
description: Run before closing Claude Code at the end of any working session. Captures what was drafted or reviewed, which skills were invoked, what worked, and what felt manual. Saves a timestamped brief to foundation/briefs/ that feeds the find-skills skill.
---

# End of Session Brief

## When to use
Invoke at the end of any working session before closing Claude Code.

## Steps

1. **Review the current session.** Gather:
   - What drafts were started, revised, or completed
   - Which skills were invoked and how many times
   - What prompts or requests were repeated
   - Outputs produced and their file paths
   - Anything that felt manual, slow, or required multiple attempts

2. **Write a structured brief** at `foundation/briefs/[YYYY-MM-DD-HH-MM].md`:

   ```markdown
   ---
   date: [YYYY-MM-DD]
   duration: [approx minutes]
   author: [name]
   ---
   
   # Session Brief
   
   ## Work completed
   - [one line per piece or task]
   
   ## Skills invoked
   - [skill name]: [N times, for what]
   
   ## Repeated requests
   - [exact description of anything run more than once]
   
   ## Outputs produced
   - [file paths]
   
   ## Friction
   - [tasks that felt manual]
   - [things that needed multiple attempts]
   
   ## Notes
   - [anything worth flagging for next session or the team]
   ```

3. **Ensure `foundation/briefs/` exists** and create it if not.

## Outputs
- One brief file saved to `foundation/briefs/[YYYY-MM-DD-HH-MM].md`

## Do not
- Do not overwrite previous briefs. Each session gets its own file.
- Do not include session content beyond a one-line summary. Briefs are metadata, not transcripts.
