---
name: draft-content
description: Produces a first draft of a piece of content from source material and foundation context. Use this when starting any new blog post, marketing copy, internal comm, technical content, social post, whitepaper, or case study. Does not fact-check. That is a separate pass.
---

# Draft Content

## When to use
Invoke this at the start of any new piece. It produces a first draft only. Fact-checking and publish-readiness run as separate skills afterward.

## Inputs expected
- **Content type** (blog, marketing copy, internal comm, technical, social, whitepaper, case study). If not specified, ask before drafting.
- **Topic or brief** (a sentence, an outline, or a longer brief).
- **Source folder** in `sources/[topic-name]/` containing any material Claude should treat as source of truth.
- **Optional**: specific angle, length override, target publish date, distribution channel.

## Steps

1. **Confirm inputs.** If content type is missing, ask. If `sources/[topic-name]/` is empty, ask whether to proceed on foundation context alone (risky) or wait for source material.

2. **Load foundation context.** Read:
   - `foundation/audience.md` for reader vocabulary and priorities
   - `foundation/voice.md` for structural and sentence-level patterns
   - `foundation/positioning.md` for claims we can and cannot make
   - `foundation/content-types.md` for the matching format profile
   - `foundation/verification-rules.md` for the banned word list to avoid up front

3. **Read all files in the source folder.** Summarize what the sources contain and what they do not cover. If a gap exists between the brief and the sources, flag it before drafting.

4. **Consult the knowledge base if relevant.** Scan `knowledge-base/` for supporting material. Only pull in what directly serves this piece.

5. **Decide on web search scope.** Default: no web search at drafting stage unless the brief explicitly requires it. Fact-checking happens later. If web search is needed, use trusted-only scope from `foundation/trusted-sources.md`.

6. **Produce the draft** in `drafts/[YYYY-MM-DD]-[slug].md`. Start the file with a front-matter block:

   ```markdown
   ---
   type: [content type]
   target-length: [word count]
   sources-used: [list of files from sources/]
   knowledge-base-used: [list of files from knowledge-base/]
   web-sources: [none at draft stage / list if used]
   status: draft
   ---
   ```

   Then write the draft. Cite every factual claim inline as you write.

7. **End with a drafting report** at the bottom of the file:
   - What the draft covers well
   - Claims that need verification in the fact-check pass
   - Gaps in source material that required inference
   - Anything you deliberately avoided because it would risk crossing into unsupported claims

## Outputs

- One draft file saved to `drafts/[YYYY-MM-DD]-[slug].md`
- Drafting report appended at the bottom of the draft

## Do not
- Do not run the fact-check pass in the same invocation. Stop at the draft.
- Do not use any of the banned words or framings in `foundation/verification-rules.md`.
- Do not fabricate stats, quotes, or case studies. If a claim isn't supported, write around it or flag it with `[VERIFY]`.
- Do not edit files outside `drafts/`.

## After this skill
Invoke `fact-check-pass` on the draft.
