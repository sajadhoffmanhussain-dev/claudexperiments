---
name: publish-ready-review
description: Produces a structured publish-readiness checklist attached to a fact-checked draft. Covers claims and sources, hyperbole audit, weasel word audit, voice fit, audience fit, positioning alignment, CTA clarity, and structural soundness. Run this after fact-check-pass to get a final green-light report before human review.
---

# Publish-Ready Review

## When to use
Invoke this after `fact-check-pass` has produced a v2 draft with no blocking issues. This is the final automated pass before human sign-off.

## Inputs expected
- Path to a fact-checked draft (usually `drafts/[slug]-v2.md`)
- Content type (inherited from the draft front matter if set)

## Steps

1. **Read the v2 draft and the fact-check log.** Understand what was flagged and fixed.

2. **Load foundation files.** Read:
   - `foundation/audience.md`
   - `foundation/voice.md`
   - `foundation/positioning.md`
   - `foundation/content-types.md`
   - `foundation/verification-rules.md`

3. **Run the publish-readiness checklist** across the categories below. For each item, mark it PASS, NEEDS ATTENTION, or FAIL. Provide a specific example from the draft for every NEEDS ATTENTION or FAIL.

   ### Claims and sources
   - Every factual claim has a citation or traceable source
   - Citations follow the format in `trusted-sources.md`
   - No claims from the "Claims we cannot make" list in `positioning.md`
   - No composite people or hypothetical scenarios presented as real

   ### Hyperbole audit
   - Zero instances of banned words from `verification-rules.md` (unless explicitly source-backed)
   - No "the only X that Y" or "X is dead" framings
   - Superlatives accompanied by evidence

   ### Weasel word audit
   - No "studies show," "experts agree," "widely believed," "leading companies," "most organizations" without specifics

   ### Voice fit
   - Opening matches the pattern in `voice.md` (no throat-clearing)
   - Sentence length varies appropriately
   - Active voice dominates
   - Word choices match the "We use" and "We avoid" lists

   ### Audience fit
   - Vocabulary matches "How they talk" in `audience.md`
   - Addresses the priorities in "What they care about"
   - Avoids framings in "What they're skeptical of"
   - Does not drift toward an audience outside "Out of scope"

   ### Positioning alignment
   - Claims align with "Claims we can make"
   - Leans on "Territory we own" rather than contested ground
   - No accidental drift into "Territory we've ceded"

   ### Content-type fit
   - Length matches the profile in `content-types.md`
   - Structure matches the profile for this content type
   - Claim density matches the profile
   - Voice tilt matches the profile
   - CTA shape matches the profile

   ### Structural soundness
   - Opening earns the next paragraph
   - Each section earns its place
   - Closing lands on something concrete
   - No orphaned sentences or transitions that only exist because an LLM likes them ("In conclusion," "As we have seen," etc.)

   ### Legal and safety sanity check
   - No claims about competitors that aren't sourced
   - No claims about customers beyond what's in `knowledge-base/case-studies/` or `sources/`
   - No advice in a domain (legal, financial, medical) that requires disclaimers

4. **Write the review report** at `reviews/[slug]-publish-ready.md`:

   ```markdown
   ---
   draft: drafts/[slug]-v2.md
   run: publish-ready-review
   date: [YYYY-MM-DD]
   ---
   
   # Publish-Ready Review: [slug]
   
   ## Headline verdict
   [GREEN: ship it] | [YELLOW: minor revisions needed] | [RED: not ready]
   
   ## Category results
   [Each category: PASS / NEEDS ATTENTION / FAIL, with specifics]
   
   ## Blocking items (if any)
   [List of things that must be fixed before publishing]
   
   ## Recommended edits (if any)
   [Optional improvements that would strengthen the piece]
   
   ## Reviewer notes for the human
   [Short note highlighting anything the human should pay particular attention to]
   ```

5. **If GREEN**, rename the draft from `[slug]-v2.md` to `[slug]-publish-ready.md` and update the front matter with `status: publish-ready`. Do not move it to `published/` yet. The human ships it.

## Outputs
- Review report at `reviews/[slug]-publish-ready.md`
- Updated draft filename and status if GREEN

## Do not
- Do not produce a GREEN verdict if any blocking items exist
- Do not edit the content of the draft during this pass. Only update front matter and filename.
- Do not compress the checklist. The whole point is that it is visible and complete.

## After this skill
Human review. On approval, move the file to `published/` with its final filename.
