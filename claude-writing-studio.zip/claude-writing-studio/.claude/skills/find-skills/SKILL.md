---
name: find-skills
description: Scans session briefs to surface patterns worth turning into new skills. Run weekly. Identifies repeated prompts, manual tasks, and multi-attempt requests, then drafts candidate SKILL.md files with proper YAML frontmatter for team review.
---

# Find Skills

## When to use
Run weekly, typically on Friday, to review the past week's briefs and surface automation candidates.

## Steps

1. **Read `foundation/briefs/reviewed.md`** to get the list of already-reviewed briefs. If the file does not exist, create it with an empty list.

2. **Scan `foundation/briefs/`** for any brief files not in `reviewed.md`. These are the unreviewed briefs for this pass.

3. **For each unreviewed brief**, extract:
   - Any prompt, task, or request marked as repeated
   - Any task that required multiple attempts
   - Any output that was manually reformatted after the skill ran
   - Any friction point the author called out

4. **Identify patterns across briefs.** Tasks or prompts that appear in more than one session are the strongest candidates. Note which briefs reference each pattern.

5. **For each candidate skill**, draft a `SKILL.md` file with:
   - Proper YAML frontmatter (`---` block with `name` and `description`)
   - A clear "When to use" section
   - Explicit steps
   - Expected inputs and outputs
   - "Do not" constraints
   - Estimated time saved per week if automated

6. **Present candidates** in a summary report with the draft `SKILL.md` files attached. Do NOT create the skills automatically. Team review first.

7. **Append the reviewed brief filenames** to `foundation/briefs/reviewed.md` so they are not scanned again next week.

## Outputs
- Candidate skills report with draft `SKILL.md` files
- Updated `foundation/briefs/reviewed.md`

## Do not
- Do not create new skills in `.claude/skills/` automatically. Propose, do not promote.
- Do not flag one-off tasks as skill candidates. A pattern needs at least two independent sessions.
- Do not write a candidate without proper YAML frontmatter. If it is worth proposing, it is worth proposing correctly.
