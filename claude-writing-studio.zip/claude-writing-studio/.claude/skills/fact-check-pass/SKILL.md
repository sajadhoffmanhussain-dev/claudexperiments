---
name: fact-check-pass
description: Self-critique pass over a completed draft. Extracts every factual claim, stat, quote, and attribution, classifies each by evidence strength, flags hyperbole and weasel words, and produces both a critique log and a revised draft with issues addressed. Run this after draft-content and before publish-ready-review.
---

# Fact-Check Pass

## When to use
Invoke this after `draft-content` produces a first draft. This is a separate pass so the critique voice does not collapse into the drafting voice.

## Inputs expected
- Path to a draft file in `drafts/[YYYY-MM-DD]-[slug].md`
- Optional: web search scope override (general, trusted-only, custom list of domains, or none)

## Steps

1. **Read the target draft** and the drafting report at its bottom.

2. **Load the verification rules.** Read `foundation/verification-rules.md` and `foundation/trusted-sources.md`. These define the classification system you will apply.

3. **Extract every factual claim.** Produce a line-by-line list of:
   - Statistics and percentages
   - Named studies, reports, or publications
   - Quotes with attribution
   - Product or feature claims
   - Market or competitive assertions
   - Customer case references
   - Dates, versions, prices, and other specifics

4. **Classify each claim.** For every claim, verify against sources in this order:
   - a. `sources/[topic]/` (the per-draft source folder)
   - b. `knowledge-base/` (persistent reference material)
   - c. Web search, scoped per the default in `foundation/trusted-sources.md` or the override for this pass
   
   Tag each claim with one of:
   - **[sourced]** - directly supported by a cited source. Include the citation.
   - **[traceable]** - supported by the knowledge base. Include the reference.
   - **[web-verified]** - supported by a web search result. Include the link and the tier (1-4) from `trusted-sources.md`.
   - **[unverifiable]** - no source found. Recommend cutting, rewriting, or pulling from a new source.
   - **[hallucinated]** - appears to be fabricated. Must be cut.

5. **Scan for hyperbole, weasel words, and puffery.** Flag every instance of the banned lists in `verification-rules.md`. For each, propose a replacement that keeps the rhetorical intent but loses the inflation.

6. **Scan for exaggeration.** Claims that might be technically true but overstated given the evidence. Note which specific word or framing is doing the overstating.

7. **Scan for voice drift.** Cross-check the draft against `foundation/voice.md`. Flag sentences that break the patterns (corporate filler, passive voice where active works, sentence-length monotony, throat-clearing openers).

8. **Produce the critique log** at `reviews/[draft-slug]-factcheck.md`:

   ```markdown
   ---
   draft: drafts/[slug].md
   run: fact-check-pass
   date: [YYYY-MM-DD]
   ---
   
   # Fact-Check Log: [slug]
   
   ## Summary
   - Total claims extracted: N
   - Sourced: N | Traceable: N | Web-verified: N | Unverifiable: N | Hallucinated: N
   - Hyperbole flags: N
   - Weasel word flags: N
   - Voice drift flags: N
   - Blocking issues: N (unverifiable + hallucinated + unsupported superlatives)
   
   ## Claim-by-claim log
   [One entry per claim with original text, classification, source or issue, suggested fix]
   
   ## Language flags
   [One entry per hyperbole, weasel word, or puffery hit with suggested replacement]
   
   ## Voice drift
   [Sentences that break the voice patterns with suggested rewrites]
   ```

9. **Produce a revised draft** at `drafts/[slug]-v2.md` with all [sourced], [traceable], and [web-verified] claims left in place with citations added, and all [unverifiable], [hallucinated], and banned-word issues fixed. Do NOT overwrite the original draft. The original stays for reference.

10. **Update the draft front matter** in v2 with `status: fact-checked` and a list of changes made.

## Outputs
- Critique log at `reviews/[slug]-factcheck.md`
- Revised draft at `drafts/[slug]-v2.md`

## Do not
- Do not overwrite the original draft. Always produce a v2.
- Do not classify a claim as [sourced] without a specific citation. Vague references do not count.
- Do not let tier 4 trade press support high-stakes claims. Flag them for human review.
- Do not move to publish-ready-review if any [hallucinated] claims remain.

## After this skill
If there are no blocking issues, invoke `publish-ready-review`. If there are blocking issues, return them to the author for source gathering or rewriting.
