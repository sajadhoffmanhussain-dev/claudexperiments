---
name: refine-web-sources
description: Sets the web search scope for the current Claude Code session or a specific draft. Use this to switch between general web search, trusted-only search scoped to domains in trusted-sources.md, or a custom source list for one piece. Use before running fact-check-pass or publish-ready-review when you need a narrower or broader search than the default.
---

# Refine Web Sources

## When to use
- Before `fact-check-pass` if the default scope is wrong for this piece
- When a draft needs to cite only specific competitors or reports
- When you want to temporarily widen search for background research, then narrow it again for citations

## Steps

1. **Read `foundation/trusted-sources.md`** to see the current default scope and the tiered domain list.

2. **Ask which scope applies** for the current session or draft:
   - a. **General** - any credible source, useful for background context
   - b. **Trusted-only** - limited to the tiered domain list in `trusted-sources.md`
   - c. **Custom** - a specific list provided for this piece only
   - d. **None** - no web search, source docs and knowledge base only

3. **If custom**, capture the allowed domains or URLs and write them to `reviews/[slug]-search-scope.md` so the choice is documented alongside the piece.

4. **Apply the scope.** Any web search in subsequent skills during this session should respect the chosen scope. If a claim cannot be supported within the scope, flag it rather than reaching outside.

5. **Record the choice.** Update the front matter of any draft or review produced in this session with a `web-scope:` field noting what was used.

## Outputs
- Scope setting applied for the session
- Optional scope note at `reviews/[slug]-search-scope.md` if custom

## Do not
- Do not silently widen the scope during a fact-check pass. If you cannot find support within the scope, flag it and return to the human.
- Do not assume a previous scope carries across sessions. Re-set it if needed.
